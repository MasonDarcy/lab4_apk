package demotiltball_28659;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import demotiltball_28659.yorku.eecs.mack.demotiltball.R;

public class ScoreScreen extends Activity {

    int laps, wallHits;
    float meanLaps;
    long timeInside, totalTime;
    TextView lapsLabel, lapTimeLabel, wallHitLabel, inPathTimeLabel;
    Button setup, exit;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scorescreen);

        Bundle b = getIntent().getExtras();
        wallHits = b.getInt("wallHits");
        laps = b.getInt("laps");
        meanLaps = b.getLong("lapMean");
        timeInside = b.getLong("totalTimeInside");
        totalTime = b.getLong("totalTime");

       lapsLabel = findViewById(R.id.lapsLabel);
       lapsLabel.setText("Laps = " + laps);
       lapTimeLabel = findViewById(R.id.laptimeLabel);
       meanLaps /= 1000000000;
       lapTimeLabel.setText("Lap time = " + String.format("%.2f", (float)meanLaps / laps) + " s (mean/lap)");
       wallHitLabel = findViewById(R.id.wallHitLabel);
       wallHitLabel.setText("Wall hits = " + wallHits);
       inPathTimeLabel = findViewById(R.id.inPathLabel);
        if(timeInside > totalTime) {
            inPathTimeLabel.setText("In-path time = 100%");
        } else {
           double c = ((double)timeInside/totalTime)*100;
            inPathTimeLabel.setText("In-path time = " + String.format("%.2f", c) + "%");
        }

       setup = findViewById(R.id.setupButton);
       exit = findViewById(R.id.exitButton);

    }

    public void goToSetup(View view) {
        Intent i = new Intent(getApplicationContext(), DemoTiltBallSetup.class);
        startActivity(i);
    }

    public void exitProgram(View view) {
        finish();
        System.exit(0);

    }


}
