package demotiltball_28659;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.MediaPlayer;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

import java.util.Locale;

import demotiltball_28659.yorku.eecs.mack.demotiltball.R;

public class RollingBallPanel extends View
{

    final static float DEGREES_TO_RADIANS = 0.0174532925f;
    int laps = 0;
    int targetLaps;
    Context appContext;
    long[] lapTimes;
    // the ball diameter will be min(width, height) / this_value
    final static float BALL_DIAMETER_ADJUST_FACTOR = 30;

    final static int DEFAULT_LABEL_TEXT_SIZE = 20; // tweak as necessary
    final static int DEFAULT_STATS_TEXT_SIZE = 10;
    final static int DEFAULT_GAP = 7; // between lines of text
    final static int DEFAULT_OFFSET = 10; // from bottom of display

    final static int MODE_NONE = 0;
    final static int PATH_TYPE_SQUARE = 1;
    final static int PATH_TYPE_CIRCLE = 2;

    final static float PATH_WIDTH_NARROW = 2f; // ... x ball diameter
    final static float PATH_WIDTH_MEDIUM = 4f; // ... x ball diameter
    final static float PATH_WIDTH_WIDE = 8f; // ... x ball diameter

    float radiusOuter, radiusInner;

    Bitmap ball, decodedBallBitmap;
    int ballDiameter;

    float dT; // time since last sensor event (seconds)

    float width, height, pixelDensity;
    int labelTextSize, statsTextSize, gap, offset;

    RectF innerRectangle, outerRectangle, ballNow, oldOuterShadowRectangle, outerShadowRectangle, oldInnerShadowRectangle, innerShadowRectangle, lapLineRectangle, firstQuadrant, secondQuadrant, thirdQuadrant, fourthQuadrant;
    boolean touchFlag;
    boolean touchFlag2;
    boolean isInside;
    boolean lapLineFlag;
    boolean gameStarted = false;
    boolean firstQuadrantFlag = false;
    boolean secondQuadrantFlag = false;
    boolean thirdQuadrantFlag = false;
    boolean fourthQuadrantFlag = false;
    boolean completedTrackFlag = false;

    //time
    long currentLapStart;
    long currentLapEnd;
    long totalTimeInside;
    long currentStartInside;
    long currentEndInside;



    Vibrator vib;
    int wallHits;

    float xBall, yBall; // top-left of the ball (for painting)
    float xBallCenter, yBallCenter; // center of the ball

    float pitch, roll;
    float tiltAngle, tiltMagnitude;

    // parameters from Setup dialog
    String orderOfControl;
    float gain, pathWidth;
    int pathType;

    float velocity; // in pixels/second (velocity = tiltMagnitude * tiltVelocityGain
    float dBall; // the amount to move the ball (in pixels): dBall = dT * velocity
    float xCenter, yCenter; // the center of the screen
    long now, lastT;
    Paint statsPaint, labelPaint, linePaint, testPaint, fillPaint, backgroundPaint, lapLine, arrowLine, arrowLeftWing, arrowRightWing;
    float[] updateY;

    public RollingBallPanel(Context contextArg)
    {
        super(contextArg);
        initialize(contextArg);
    }

    public RollingBallPanel(Context contextArg, AttributeSet attrs)
    {
        super(contextArg, attrs);
        initialize(contextArg);
    }

    public RollingBallPanel(Context contextArg, AttributeSet attrs, int defStyle)
    {
        super(contextArg, attrs, defStyle);
        initialize(contextArg);
    }

    // things that can be initialized from within this View
    private void initialize(Context c)
    {
        linePaint = new Paint();
        linePaint.setColor(Color.RED);
        linePaint.setStyle(Paint.Style.STROKE);
        linePaint.setStrokeWidth(2);
        linePaint.setAntiAlias(true);

        lapLine = new Paint();
        lapLine.setColor(Color.RED);
        lapLine.setStyle(Paint.Style.STROKE);
        lapLine.setStrokeWidth(2);
        lapLine.setAntiAlias(true);



        arrowLine = new Paint();
        arrowLine.setColor(Color.RED);
        arrowLine.setStyle(Paint.Style.STROKE);
        arrowLine.setStrokeWidth(2);
        arrowLine.setAntiAlias(true);

        arrowLeftWing = new Paint();
        arrowLeftWing.setColor(Color.RED);
        arrowLeftWing.setStyle(Paint.Style.STROKE);
        arrowLeftWing.setStrokeWidth(2);
        arrowLeftWing.setAntiAlias(true);

        arrowRightWing = new Paint();
        arrowRightWing.setColor(Color.RED);
        arrowRightWing.setStyle(Paint.Style.STROKE);
        arrowRightWing.setStrokeWidth(2);
        arrowRightWing.setAntiAlias(true);


        fillPaint = new Paint();
        fillPaint.setColor(0xffccbbbb);
        fillPaint.setStyle(Paint.Style.FILL);

        testPaint = new Paint();
        testPaint.setColor(0xffffffff);
        testPaint.setStyle(Paint.Style.FILL);

        backgroundPaint = new Paint();
        backgroundPaint.setColor(Color.LTGRAY);
        backgroundPaint.setStyle(Paint.Style.FILL);

        labelPaint = new Paint();
        labelPaint.setColor(Color.BLACK);
        labelPaint.setTextSize(DEFAULT_LABEL_TEXT_SIZE);
        labelPaint.setAntiAlias(true);

        statsPaint = new Paint();
        statsPaint.setAntiAlias(true);
        statsPaint.setTextSize(DEFAULT_STATS_TEXT_SIZE);

        // NOTE: we'll create the actual bitmap in onWindowFocusChanged
        decodedBallBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.ball);

        lastT = System.nanoTime();
        this.setBackgroundColor(Color.LTGRAY);
        touchFlag = false;
        touchFlag2 = false;
        isInside = true;
        lapLineFlag = false;
        outerRectangle = new RectF();
        innerRectangle = new RectF();

        outerShadowRectangle = new RectF();
        innerShadowRectangle = new RectF();
        oldOuterShadowRectangle = new RectF();
        oldInnerShadowRectangle = new RectF();
        lapLineRectangle = new RectF();
        ballNow = new RectF();
        firstQuadrant = new RectF();
        secondQuadrant = new RectF();
        thirdQuadrant = new RectF();
        fourthQuadrant = new RectF();
        wallHits = 0;
        totalTimeInside = 0;

        vib = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
    }

    /**
     * Called when the window hosting this view gains or looses focus.  Here we initialize things that depend on the
     * view's width and height.
     */
    @Override
    public void onWindowFocusChanged(boolean hasFocus)
    {
        if (!hasFocus)
            return;

        width = this.getWidth();
        height = this.getHeight();

        // the ball diameter is nominally 1/30th the smaller of the view's width or height
        ballDiameter = width < height ? (int)(width / BALL_DIAMETER_ADJUST_FACTOR)
                : (int)(height / BALL_DIAMETER_ADJUST_FACTOR);

        // now that we know the ball's diameter, get a bitmap for the ball
        ball = Bitmap.createScaledBitmap(decodedBallBitmap, ballDiameter, ballDiameter, true);

        // center of the view
        xCenter = width / 2f;
        yCenter = height / 2f;

        // top-left corner of the ball
        xBall = xCenter - (width < height ? 0.40f * width : 0.40f * height) / 1.5F;
        yBall = yCenter - 60;
//        xBall = xCenter - (width < height ? 0.40f * width : 0.40f * height) + 20;
//        yBall = yCenter + 30;

        // center of the ball
        xBallCenter = xBall + ballDiameter / 2f;
        yBallCenter = yBall + ballDiameter / 2f;

        // configure outer rectangle of the path
        radiusOuter = width < height ? 0.40f * width : 0.40f * height;
        outerRectangle.left = xCenter - radiusOuter;
        outerRectangle.top = yCenter - radiusOuter;
        outerRectangle.right = xCenter + radiusOuter;
        outerRectangle.bottom = yCenter + radiusOuter;

        // configure inner rectangle of the path
        // NOTE: medium path width is 4 x ball diameter
        radiusInner = radiusOuter - pathWidth * ballDiameter;
        innerRectangle.left = xCenter - radiusInner;
        innerRectangle.top = yCenter - radiusInner;
        innerRectangle.right = xCenter + radiusInner;
        innerRectangle.bottom = yCenter + radiusInner;

        //lapLineRectangle
        lapLineRectangle.left = xCenter - radiusOuter;
        lapLineRectangle.top = yCenter;
        lapLineRectangle.right = xCenter - radiusInner;
        lapLineRectangle.bottom = yCenter;

        //Outer shadow rectangle
        outerShadowRectangle.left = xCenter - radiusOuter - ballDiameter + 2F;
        outerShadowRectangle.top = yCenter - radiusOuter - ballDiameter + 2F;
        outerShadowRectangle.right = xCenter + radiusOuter + ballDiameter - 2F;
        outerShadowRectangle.bottom = yCenter + radiusOuter + ballDiameter - 2F;

        //Inner shadow rectangle
        innerShadowRectangle.left = innerRectangle.left - ballDiameter - 2f;
        innerShadowRectangle.top = innerRectangle.top - ballDiameter - 2f;
        innerShadowRectangle.right = innerRectangle.right + ballDiameter + 2f;
        innerShadowRectangle.bottom = innerRectangle.bottom + ballDiameter + 2f;


        //old rectangles
        oldOuterShadowRectangle.left = outerRectangle.left + ballDiameter - 2f;
        oldOuterShadowRectangle.top = outerRectangle.top + ballDiameter - 2f;
        oldOuterShadowRectangle.right = outerRectangle.right - ballDiameter + 2f;
        oldOuterShadowRectangle.bottom = outerRectangle.bottom - ballDiameter + 2f;

        oldInnerShadowRectangle.left = innerRectangle.left + ballDiameter - 2f;
        oldInnerShadowRectangle.top = innerRectangle.top + ballDiameter - 2f;
        oldInnerShadowRectangle.right = innerRectangle.right - ballDiameter + 2f;
        oldInnerShadowRectangle.bottom = innerRectangle.bottom - ballDiameter + 2f;

        //Quadrants
        firstQuadrant.left = 0;
        firstQuadrant.top = yCenter;
        firstQuadrant.right = xCenter;
        firstQuadrant.bottom = yCenter * 2;

        secondQuadrant.left = xCenter;
        secondQuadrant.top = yCenter;
        secondQuadrant.right = xCenter * 2;
        secondQuadrant.bottom = yCenter * 2;

        thirdQuadrant.left = xCenter;
        thirdQuadrant.top = 0;
        thirdQuadrant.right = xCenter * 2;
        thirdQuadrant.bottom = yCenter;

        fourthQuadrant.left = 0;
        fourthQuadrant.top = 0;
        fourthQuadrant.right = xCenter;
        fourthQuadrant.bottom = yCenter;

        // initialize a few things (e.g., paint and text size) that depend on the device's pixel density
        pixelDensity = this.getResources().getDisplayMetrics().density;
        labelTextSize = (int)(DEFAULT_LABEL_TEXT_SIZE * pixelDensity + 0.5f);
        labelPaint.setTextSize(labelTextSize);

        statsTextSize = (int)(DEFAULT_STATS_TEXT_SIZE * pixelDensity + 0.5f);
        statsPaint.setTextSize(statsTextSize);

        gap = (int)(DEFAULT_GAP * pixelDensity + 0.5f);
        offset = (int)(DEFAULT_OFFSET * pixelDensity + 0.5f);

        // compute y offsets for painting stats (bottom-left of display)
     //   updateY = new float[6]; // up to 6 lines of stats will appear
        updateY = new float[7]; // up to 6 lines of stats will appear
        for (int i = 0; i < updateY.length; ++i)
            updateY[i] = height - offset - i * (statsTextSize + gap);
    }

    /*
     * Do the heavy lifting here! Update the ball position based on the tilt angle, tilt
     * magnitude, order of control, etc.
     */
    public void updateBallPosition(float pitchArg, float rollArg, float tiltAngleArg, float tiltMagnitudeArg)
    {
        pitch = pitchArg; // for information only (see onDraw)
        roll = rollArg; // for information only (see onDraw)
        tiltAngle = tiltAngleArg;
        tiltMagnitude = tiltMagnitudeArg;

        // get current time and delta since last onDraw
        now = System.nanoTime();
        dT = (now - lastT) / 1000000000f; // seconds
        lastT = now;

        // don't allow tiltMagnitude to exceed 45 degrees
        final float MAX_MAGNITUDE = 45f;
        tiltMagnitude = tiltMagnitude > MAX_MAGNITUDE ? MAX_MAGNITUDE : tiltMagnitude;

        // This is the only code that distinguishes velocity-control from position-control
        if (orderOfControl.equals("Velocity")) // velocity control
        {
            // compute ball velocity (depends on the tilt of the device and the gain setting)
            velocity = tiltMagnitude * gain;

            // compute how far the ball should move (depends on the velocity and the elapsed time since last update)
            dBall = dT * velocity; // make the ball move this amount (pixels)

            // compute the ball's new coordinates (depends on the angle of the device and dBall, as just computed)
            float dx = (float)Math.sin(tiltAngle * DEGREES_TO_RADIANS) * dBall;
            float dy = -(float)Math.cos(tiltAngle * DEGREES_TO_RADIANS) * dBall;
            xBall += dx;
            yBall += dy;

        } else
        // position control
        {
            // compute how far the ball should move (depends on the tilt of the device and the gain setting)
            dBall = tiltMagnitude * gain;

            // compute the ball's new coordinates (depends on the angle of the device and dBall, as just computed)
            float dx = (float)Math.sin(tiltAngle * DEGREES_TO_RADIANS) * dBall;
            float dy = -(float)Math.cos(tiltAngle * DEGREES_TO_RADIANS) * dBall;
            xBall = xCenter + dx;
            yBall = yCenter + dy;
        }

        // make an adjustment, if necessary, to keep the ball visible (also, restore if NaN)
        if (Float.isNaN(xBall) || xBall < 0)
            xBall = 0;
        else if (xBall > width - ballDiameter)
            xBall = width - ballDiameter;
        if (Float.isNaN(yBall) || yBall < 0)
            yBall = 0;
        else if (yBall > height - ballDiameter)
            yBall = height - ballDiameter;

        // oh yea, don't forget to update the coordinate of the center of the ball (needed to determine wall  hits)
        xBallCenter = xBall + ballDiameter / 2f;
        yBallCenter = yBall + ballDiameter / 2f;

        // if ball touches wall, vibrate and increment wallHits count
        // NOTE: We also use a boolean touchFlag so we only vibrate on the first touch

if(gameStarted) {

    if (ballTouchingLine() && !touchFlag) {

        touchFlag = true; // the ball has *just* touched the line: set the touchFlag
        vib.vibrate(20); // 20 ms vibrotactile pulse
        ++wallHits;

    } else if (!ballTouchingLine() && touchFlag)
        touchFlag = false; // the ball is no longer touching the line: clear the touchFlag


    if (oldBallTouchingLine() && !touchFlag2)
    {
        touchFlag2 = true; // the ball has *just* touched the line: set the touchFlag
        if(isInside) {
            currentEndInside = System.nanoTime();
            long timeToAdd = (currentEndInside - currentStartInside);
            totalTimeInside += timeToAdd;
            isInside = false;
            Log.i("MYDEBUG", "totalTimeInsideIncremented to: " + totalTimeInside);
        } else {
            currentStartInside = System.nanoTime();

            Log.i("MYDEBUG", "currentStartInside fired: " + currentStartInside);

            isInside = true;
        }

    } else if (!oldBallTouchingLine() && touchFlag2)
        touchFlag2 = false; // the ball is no longer touching the line: clear the touchFlag


    if (ballTouchingFirstQuadrant()) {
        firstQuadrantFlag = true;
    }

    if (ballTouchingSecondQuadrant()) {
        secondQuadrantFlag = true;
    }

    if (ballTouchingThirdQuadrant()) {
        thirdQuadrantFlag = true;
    }

    if (ballTouchingFourthQuadrant()) {
        fourthQuadrantFlag = true;
    }
    completedTrackFlag = (firstQuadrantFlag && secondQuadrantFlag) && (thirdQuadrantFlag && fourthQuadrantFlag);

    antiCheat();

    if (ballTouchingLapLine() && completedTrackFlag) {

        currentLapEnd = System.nanoTime();
        lapTimes[laps] = currentLapEnd - currentLapStart;
        currentLapStart = System.nanoTime();
        ++laps;
        MediaPlayer mp = MediaPlayer.create(appContext, R.raw.slurp);
        mp.start();

        firstQuadrantFlag = false;
        secondQuadrantFlag = false;
        thirdQuadrantFlag = false;
        fourthQuadrantFlag = false;

    }
} else {
    if(ballTouchingLapLine()) {
        gameStarted = true;
        currentLapStart = System.nanoTime();
        currentStartInside = currentLapStart;
    }
}
        invalidate(); // force onDraw to redraw the screen with the ball in its new position
    }

    protected void onDraw(Canvas canvas)
    {
        // draw the paths
        if (pathType == PATH_TYPE_SQUARE)
        {
            // draw fills
            canvas.drawRect(outerRectangle, fillPaint);
            canvas.drawRect(innerRectangle, backgroundPaint);
           // canvas.drawRect(fourthQuadrant, testPaint);
//            canvas.drawRect(lapLineBottomRectangle, testPaint);;
            // draw lines
            canvas.drawRect(outerRectangle, linePaint);
            canvas.drawRect(innerRectangle, linePaint);
            //Draw lap line
            canvas.drawLine(xCenter - radiusOuter, yCenter, xCenter - radiusInner,  yCenter, lapLine);
            //Draw arrow
            canvas.drawLine(xCenter - radiusOuter - 15, yCenter - 40, xCenter - radiusOuter - 15, yCenter + 40, arrowLine);
            canvas.drawLine(xCenter - radiusOuter - 25, yCenter, xCenter - radiusOuter - 15, yCenter + 40, arrowLeftWing);
            canvas.drawLine(xCenter - radiusOuter - 5, yCenter, xCenter - radiusOuter - 15, yCenter + 40, arrowRightWing);



        } else if (pathType == PATH_TYPE_CIRCLE)
        {
            // draw fills
            canvas.drawOval(outerRectangle, fillPaint);
            canvas.drawOval(innerRectangle, backgroundPaint);

            // draw lines
            canvas.drawOval(outerRectangle, linePaint);
            canvas.drawOval(innerRectangle, linePaint);
            canvas.drawLine(xCenter - radiusOuter, yCenter, xCenter - radiusInner,  yCenter, lapLine);
            canvas.drawLine(xCenter - radiusOuter - 15, yCenter - 40, xCenter - radiusOuter - 15, yCenter + 40, arrowLine);
            canvas.drawLine(xCenter - radiusOuter - 25, yCenter, xCenter - radiusOuter - 15, yCenter + 40, arrowLeftWing);
            canvas.drawLine(xCenter - radiusOuter - 5, yCenter, xCenter - radiusOuter - 15, yCenter + 40, arrowRightWing);


        }

        // draw label
        canvas.drawText("Demo_TiltBall", 6f, labelTextSize, labelPaint);

        // draw stats (pitch, roll, tilt angle, tilt magnitude)
        if (pathType == PATH_TYPE_SQUARE || pathType == PATH_TYPE_CIRCLE)
        {
            canvas.drawText("Wall hits = " + wallHits, 6f, updateY[6], statsPaint);
            canvas.drawText("-----------------", 6f, updateY[5], statsPaint);
        }
        canvas.drawText(String.format(Locale.CANADA, "Current lap: %d", laps + 1), 6f, updateY[4],
                statsPaint);
        canvas.drawText(String.format(Locale.CANADA, "Tablet pitch (degrees) = %.2f", pitch), 6f, updateY[3],
                statsPaint);
        canvas.drawText(String.format(Locale.CANADA, "Tablet roll (degrees) = %.2f", roll), 6f, updateY[2], statsPaint);
        canvas.drawText(String.format(Locale.CANADA, "Ball x = %.2f", xBallCenter), 6f, updateY[1], statsPaint);
        canvas.drawText(String.format(Locale.CANADA, "Ball y = %.2f", yBallCenter), 6f, updateY[0], statsPaint);

        // draw the ball in its new location
        canvas.drawBitmap(ball, xBall, yBall, null);


    } // end onDraw

    /*
     * Configure the rolling ball panel according to setup parameters
     */
    public void configure(String pathMode, String pathWidthArg, int gainArg, String orderOfControlArg, int laps, Context context)
    {
        targetLaps = laps;
        appContext = context;
        lapTimes = new long[laps];

        // square vs. circle
        if (pathMode.equals("Square"))
            pathType = PATH_TYPE_SQUARE;
        else if (pathMode.equals("Circle"))
            pathType = PATH_TYPE_CIRCLE;
        else
            pathType = MODE_NONE;

        Log.i("MYDEBUG", "Path width: + " + pathWidth);
        // narrow vs. medium vs. wide
        if (pathWidthArg.equals("Narrow"))
            pathWidth = PATH_WIDTH_NARROW;
        else if (pathWidthArg.equals("Wide"))
            pathWidth = PATH_WIDTH_WIDE;
        else
            pathWidth = PATH_WIDTH_MEDIUM;

        gain = gainArg;
        orderOfControl = orderOfControlArg;
    }

    // returns true if the ball is touching (i.e., overlapping) the line of the inner or outer path border
    public boolean ballTouchingLine()
    {
        if (pathType == PATH_TYPE_SQUARE)
        {
            ballNow.left = xBall;
            ballNow.top = yBall;
            ballNow.right = xBall + ballDiameter;
            ballNow.bottom = yBall + ballDiameter;


            if (!RectF.intersects(ballNow, outerRectangle) || !RectF.intersects(ballNow, outerShadowRectangle))
                return true; // touching outside rectangular border

            if (RectF.intersects(ballNow, innerRectangle) && RectF.intersects(ballNow, innerShadowRectangle))
                return true; // touching inside rectangular border

        } else if (pathType == PATH_TYPE_CIRCLE)
        {
            final float ballDistance = (float)Math.sqrt((xBallCenter - xCenter) * (xBallCenter - xCenter)
                    + (yBallCenter - yCenter) * (yBallCenter - yCenter));

            if (!((ballDistance - radiusOuter) < (ballDiameter / 2f)))
                           return true; // touching outer circular border

            if (((ballDistance - radiusInner) < (ballDiameter / 2f)))
                return true; // touching inner circular border
        }

        return false;
    }

    public boolean oldBallTouchingLine()
    {
        if (pathType == PATH_TYPE_SQUARE)
        {
            ballNow.left = xBall;
            ballNow.top = yBall;
            ballNow.right = xBall + ballDiameter;
            ballNow.bottom = yBall + ballDiameter;

            if (RectF.intersects(ballNow, outerRectangle) && !RectF.intersects(ballNow, oldOuterShadowRectangle))
                return true; // touching outside rectangular border

            if (RectF.intersects(ballNow, innerRectangle) && !RectF.intersects(ballNow, oldInnerShadowRectangle))
                return true; // touching inside rectangular border

        } else if (pathType == PATH_TYPE_CIRCLE)
        {
            final float ballDistance = (float)Math.sqrt((xBallCenter - xCenter) * (xBallCenter - xCenter)
                    + (yBallCenter - yCenter) * (yBallCenter - yCenter));

            if (Math.abs(ballDistance - radiusOuter) < (ballDiameter / 2f))
                return true; // touching outer circular border

            if (Math.abs(ballDistance - radiusInner) < (ballDiameter / 2f))
                return true; // touching inner circular border
        }
        return false;
    }

    public void setBallNow() {
        ballNow.left = xBall;
        ballNow.top = yBall;
        ballNow.right = xBall + ballDiameter;
        ballNow.bottom = yBall + ballDiameter;
    }

    public boolean ballTouchingLapLine() {

        setBallNow();


        if(RectF.intersects(ballNow, lapLineRectangle)) {
            return true;
        } else {
            return false;
        }

    }

    public boolean ballTouchingFirstQuadrant() {
        setBallNow();

        if(RectF.intersects(ballNow, firstQuadrant)) {
            return true;
        }
        return false;
    }

    public boolean ballTouchingSecondQuadrant() {
        setBallNow();

        if(RectF.intersects(ballNow, secondQuadrant)) {
            return true;
        }
        return false;
    }

    public boolean ballTouchingThirdQuadrant() {
        setBallNow();

        if(RectF.intersects(ballNow, thirdQuadrant)) {
           return true;
        }
        return false;
    }

    public boolean ballTouchingFourthQuadrant() {
        setBallNow();

        if(RectF.intersects(ballNow, fourthQuadrant)) {
            return true;
        }
        return false;
    }

    public void antiCheat() {
        boolean foundError = false;
        int currentValue = 1;
        int[] order = new int[4];

            order[0] = firstQuadrantFlag ? 1 : 0;
            order[1] = secondQuadrantFlag ? 1 : 0;
            order[2] = thirdQuadrantFlag ? 1 : 0;
            order[3] = fourthQuadrantFlag ? 1 : 0;

            for(int i = 0; i < order.length; i++) {
                if(currentValue < order[i]) {
                    foundError = true;
                } else {
                    currentValue = order[i];
                }


        }

            if(foundError) {
                firstQuadrantFlag = false;
                secondQuadrantFlag = false;
                thirdQuadrantFlag = false;
                fourthQuadrantFlag = false;
            }


    }

    public int getLaps() {
        return laps;
    }

    public long getLapMean() {
        long lapMean = 0;
        for(int i = 0; i < lapTimes.length; i++) {
            lapMean += lapTimes[i];
        }
        return lapMean;
    }

    public long getTotalTimeInside() {
        return totalTimeInside;
    }

    public int getWallHits() {
        return wallHits;
    }

    public long getTotalTime() {
        long total = 0;
        for(int i = 0; i < lapTimes.length; i++) {
            total +=lapTimes[i];


        }
        return total;
    }

public void stampTime() {
  //  currentEndInside = System.nanoTime();
    if(isInside) {
        currentEndInside = currentLapEnd;
//        Log.i("MYDEBUG", "currentLapEnd before stamp fired." + currentLapEnd);
//        Log.i("MYDEBUG", "currentStartInside before stamp fired." + currentStartInside);
//        Log.i("MYDEBUG", "TotalTimeInside before stamp fired." + totalTimeInside);
//        Log.i("MYDEBUG", "isInside: " + isInside);
        long timeToAdd = (currentEndInside - currentStartInside);
        totalTimeInside += timeToAdd;
//        Log.i("MYDEBUG", "TotalTimeInside after stamp fired." + totalTimeInside);
//        Log.i("MYDEBUG", "Stamp time fired.");
    }
}

}
